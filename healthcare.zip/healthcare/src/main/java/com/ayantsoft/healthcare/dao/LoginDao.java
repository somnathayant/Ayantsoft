package com.ayantsoft.healthcare.dao;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.ayantsoft.hibernate.pojo.UserMst;



@Repository
public class LoginDao {

	@Autowired
	private HibernateTemplate hibernateTemplate; 
    
	@Transactional
	public void insertEmpDao(){
		try{
		hibernateTemplate.save(null);
		hibernateTemplate.save(null);
		}catch(Exception ex){
			
		}

	}
	public boolean checkUserInfo(UserMst userMst){
		try{
				
			if(userMst.getUserName().equals("")){
				//hibernateTemplate.save(userMst);
				return true;
			}else{
				return false;
			}
			
		}catch(Exception ex){
			return false;
		}
		finally{
			
		}
	}
	
}
