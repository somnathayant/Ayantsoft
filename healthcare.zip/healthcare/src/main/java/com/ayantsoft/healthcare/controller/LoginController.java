package com.ayantsoft.healthcare.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLConnection;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.healthcare.service.LoginService;
import com.ayantsoft.hibernate.pojo.PatientMst;
import com.ayantsoft.hibernate.pojo.UserMst;

@RestController
public class LoginController {

	@Autowired
	private LoginService loginService;
	
	 @RequestMapping("/")  
	    public ModelAndView welcome() {  
	   ModelAndView mv=new ModelAndView();
	   UserMst user=new UserMst();
		 mv.setViewName("login");
		 mv.addObject("user",user);
		 return mv;
		}  
	
	 @RequestMapping(value={"/checkLogin"},method={RequestMethod.POST})  
	    public ModelAndView checkLogin(HttpServletResponse response,@RequestParam("files") MultipartFile files,@ModelAttribute("user")UserMst userMst) {  

		 ModelAndView mv=new ModelAndView();
		 //boolean v=loginService.userCheckInfo(userMst);
		 System.out.println("okk");
			        
		
		 if(userMst.getUserName().equals("somnath")){
			 mv.setViewName("home");
			 return mv;
		 }else{
			 mv.setViewName("login");
			 return mv;
		 }
		 
	 
	 }  
	 @RequestMapping("/patientReg")  
	    public ModelAndView showPatientReg() {  
	   ModelAndView mv=new ModelAndView();
	   PatientMst patientMst=new PatientMst();
		 mv.setViewName("patientReg");
		 mv.addObject("patientReg",patientMst);
		 return mv;
		}  
}
